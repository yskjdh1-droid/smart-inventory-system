// ── routes/admin.js ───────────────────────────────
const router = require('express').Router();
const { Equipment, Rental, User, Penalty } = require('../models');
const { authMiddleware, adminOnly } = require('../middleware/auth');

// 대시보드 통계
router.get('/stats', authMiddleware, adminOnly, async (req, res) => {
  try {
    const [total, available, rented, repairing, overdue, todayReturns] = await Promise.all([
      Equipment.countDocuments(),
      Equipment.countDocuments({ status: 'AVAILABLE' }),
      Equipment.countDocuments({ status: 'RENTED' }),
      Equipment.countDocuments({ status: 'REPAIRING' }),
      Rental.countDocuments({ status: 'OVERDUE' }),
      Rental.countDocuments({
        status: 'ACTIVE',
        dueDate: {
          $gte: new Date(new Date().setHours(0, 0, 0, 0)),
          $lt:  new Date(new Date().setHours(23, 59, 59, 999)),
        },
      }),
    ]);
    res.json({ total, available, rented, repairing, overdue, todayReturns });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 연체 목록
router.get('/overdue', authMiddleware, adminOnly, async (req, res) => {
  const list = await Rental.find({ status: 'OVERDUE' })
    .populate('user', 'name studentId phone')
    .populate('equipment', 'modelName serialNumber')
    .sort({ dueDate: 1 });
  res.json(list);
});

// 오늘 반납 예정
router.get('/due-today', authMiddleware, adminOnly, async (req, res) => {
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const end   = new Date(); end.setHours(23, 59, 59, 999);
  const list = await Rental.find({ status: 'ACTIVE', dueDate: { $gte: start, $lte: end } })
    .populate('user', 'name studentId')
    .populate('equipment', 'modelName serialNumber');
  res.json(list);
});

// 패널티 부과 (수동)
router.post('/penalty', authMiddleware, adminOnly, async (req, res) => {
  try {
    const { userId, score, reason, rentalId } = req.body;
    await Penalty.create({ user: userId, rental: rentalId, score, reason, issuedBy: req.user._id });
    await User.findByIdAndUpdate(userId, { $inc: { penaltyScore: score } });

    // 패널티 10점 초과 시 대여 정지
    const user = await User.findById(userId);
    if (user.penaltyScore >= 10 && !user.isSuspended) {
      user.isSuspended = true;
      await user.save();
    }
    res.status(201).json({ message: `패널티 ${score}점 부과됐습니다.` });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 패널티 감면
router.put('/penalty/:userId/reduce', authMiddleware, adminOnly, async (req, res) => {
  try {
    const { score, reason } = req.body;
    await Penalty.create({ user: req.params.userId, score: -score, reason, issuedBy: req.user._id });
    const user = await User.findByIdAndUpdate(
      req.params.userId,
      { $inc: { penaltyScore: -score } },
      { new: true }
    );
    if (user.penaltyScore < 10) {
      user.isSuspended = false;
      await user.save();
    }
    res.json({ message: `패널티 ${score}점 감면됐습니다.` });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 사용자 목록 + 패널티 현황
router.get('/users', authMiddleware, adminOnly, async (req, res) => {
  const users = await User.find().select('-password').sort({ penaltyScore: -1 });
  res.json(users);
});

module.exports = router;
