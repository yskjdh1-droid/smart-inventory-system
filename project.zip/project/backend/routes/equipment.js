// ── routes/equipment.js ───────────────────────────
const router   = require('express').Router();
const QRCode   = require('qrcode');
const multer   = require('multer');
const { Equipment, StatusHistory } = require('../models');
const { authMiddleware, adminOnly } = require('../middleware/auth');

const upload = multer({ dest: 'uploads/' });

// 목록 조회
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { search, category, status } = req.query;
    const query = {};
    if (search) query.$or = [
      { modelName: new RegExp(search, 'i') },
      { serialNumber: new RegExp(search, 'i') },
    ];
    if (category) query.category = category;
    if (status)   query.status = status;
    const items = await Equipment.find(query).populate('category', 'name').populate('managedBy', 'name');
    res.json(items);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 단건 조회
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const item = await Equipment.findById(req.params.id)
      .populate('category').populate('managedBy', 'name');
    if (!item) return res.status(404).json({ message: '기자재를 찾을 수 없습니다.' });
    res.json(item);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 기자재 등록 (관리자)
router.post('/', authMiddleware, adminOnly, upload.array('images', 3), async (req, res) => {
  try {
    const item = await Equipment.create({
      ...req.body,
      managedBy: req.user._id,
      images: req.files?.map((f) => f.path) || [],
    });
    // QR 코드 생성
    const qrData = `${process.env.APP_URL || 'http://localhost:3000'}/equipment/${item._id}`;
    const qrUrl  = await QRCode.toDataURL(qrData);
    item.qrCodeUrl = qrUrl;
    await item.save();
    res.status(201).json(item);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 기자재 수정 (관리자)
router.put('/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const prev = await Equipment.findById(req.params.id);
    const item  = await Equipment.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (prev.status !== item.status) {
      await StatusHistory.create({ equipment: item._id, admin: req.user._id, status: item.status, reason: req.body.reason });
    }
    res.json(item);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// QR 코드 조회
router.get('/:id/qr', authMiddleware, async (req, res) => {
  const item = await Equipment.findById(req.params.id);
  if (!item) return res.status(404).json({ message: '없음' });
  res.json({ qrCodeUrl: item.qrCodeUrl });
});

// 기자재 삭제 (관리자)
router.delete('/:id', authMiddleware, adminOnly, async (req, res) => {
  await Equipment.findByIdAndDelete(req.params.id);
  res.json({ message: '삭제됐습니다.' });
});

module.exports = router;
