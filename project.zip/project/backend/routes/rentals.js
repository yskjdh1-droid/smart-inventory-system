// ── routes/rentals.js ─────────────────────────────
const router = require('express').Router();
const multer = require('multer');
const { Rental, Equipment, User, Penalty } = require('../models');
const { authMiddleware, adminOnly } = require('../middleware/auth');

const upload = multer({ dest: 'uploads/return-photos/' });

// 내 대여 목록
router.get('/my', authMiddleware, async (req, res) => {
  const rentals = await Rental.find({ user: req.user._id })
    .populate('equipment', 'modelName serialNumber')
    .sort({ createdAt: -1 });
  res.json(rentals);
});

// 전체 대여 목록 (관리자)
router.get('/', authMiddleware, adminOnly, async (req, res) => {
  const { status } = req.query;
  const query = status ? { status } : {};
  const rentals = await Rental.find(query)
    .populate('user', 'name studentId')
    .populate('equipment', 'modelName serialNumber')
    .sort({ createdAt: -1 });
  res.json(rentals);
});

// 대여 신청
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { equipmentId, dueDate, purpose } = req.body;

    if (req.user.isSuspended)
      return res.status(403).json({ message: '패널티로 인해 대여가 정지됐습니다.' });

    const equipment = await Equipment.findById(equipmentId);
    if (!equipment || equipment.status !== 'AVAILABLE')
      return res.status(400).json({ message: '대여할 수 없는 기자재입니다.' });

    const rental = await Rental.create({ user: req.user._id, equipment: equipmentId, dueDate, purpose });
    equipment.status = 'RENTED';
    await equipment.save();
    res.status(201).json(rental);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 반납 처리
router.put('/:id/return', authMiddleware, upload.single('photo'), async (req, res) => {
  try {
    const rental = await Rental.findById(req.params.id);
    if (!rental || rental.status === 'RETURNED')
      return res.status(400).json({ message: '이미 반납된 대여입니다.' });

    rental.status = 'RETURNED';
    rental.returnDate = new Date();
    rental.returnPhotoUrl = req.file?.path || '';
    await rental.save();

    await Equipment.findByIdAndUpdate(rental.equipment, { status: 'AVAILABLE' });
    res.json({ message: '반납이 완료됐습니다.' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 연장 신청
router.put('/:id/extend', authMiddleware, async (req, res) => {
  try {
    const { newDueDate } = req.body;
    const rental = await Rental.findById(req.params.id);
    if (!rental || rental.user.toString() !== req.user._id.toString())
      return res.status(403).json({ message: '권한이 없습니다.' });

    rental.dueDate = newDueDate;
    await rental.save();
    res.json({ message: '연장 신청이 접수됐습니다. 관리자 승인 후 확정됩니다.' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 강제 반납 (관리자)
router.put('/:id/force-return', authMiddleware, adminOnly, async (req, res) => {
  try {
    const { reason } = req.body;
    const rental = await Rental.findById(req.params.id);
    if (!rental) return res.status(404).json({ message: '대여 내역을 찾을 수 없습니다.' });

    rental.status = 'RETURNED';
    rental.returnDate = new Date();
    rental.isForceReturn = true;
    rental.forceReturnReason = reason;
    rental.forceReturnBy = req.user._id;
    await rental.save();

    await Equipment.findByIdAndUpdate(rental.equipment, { status: 'AVAILABLE' });
    res.json({ message: '강제 반납 처리됐습니다.' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
