// ── routes/auth.js ────────────────────────────────
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, Admin } = require('../models');
const { authMiddleware } = require('../middleware/auth');

const sign = (id, role) =>
  jwt.sign({ id, role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN });

// 학생 로그인
router.post('/login', async (req, res) => {
  try {
    const { studentId, password } = req.body;
    const user = await User.findOne({ studentId });
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ message: '학번 또는 비밀번호가 올바르지 않습니다.' });
    res.json({ token: sign(user._id, 'user'), user: { ...user.toObject(), password: undefined } });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 관리자 로그인
router.post('/admin/login', async (req, res) => {
  try {
    const { adminId, password } = req.body;
    const admin = await Admin.findOne({ adminId });
    if (!admin || !(await bcrypt.compare(password, admin.password)))
      return res.status(401).json({ message: '관리자 ID 또는 비밀번호가 올바르지 않습니다.' });
    res.json({ token: sign(admin._id, 'admin'), admin: { ...admin.toObject(), password: undefined, role: 'admin' } });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// 내 정보
router.get('/me', authMiddleware, (req, res) => res.json(req.user));

module.exports = router;
