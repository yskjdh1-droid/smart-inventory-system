// ── routes/categories.js ──────────────────────────
const router = require('express').Router();
const { Category } = require('../models');
const { authMiddleware, adminOnly } = require('../middleware/auth');

router.get('/',     authMiddleware, async (req, res) => {
  res.json(await Category.find());
});
router.post('/',    authMiddleware, adminOnly, async (req, res) => {
  res.status(201).json(await Category.create(req.body));
});
router.put('/:id',  authMiddleware, adminOnly, async (req, res) => {
  res.json(await Category.findByIdAndUpdate(req.params.id, req.body, { new: true }));
});
router.delete('/:id', authMiddleware, adminOnly, async (req, res) => {
  await Category.findByIdAndDelete(req.params.id);
  res.json({ message: '삭제됐습니다.' });
});

module.exports = router;
