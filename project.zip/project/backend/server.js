require('dotenv').config();
const express  = require('express');
const mongoose = require('mongoose');
const cors     = require('cors');
const cron     = require('node-cron');
const { Rental, User, Penalty } = require('./models');

const app = express();

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// ── Routes ────────────────────────────────────────
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/categories', require('./routes/categories'));
app.use('/api/equipment',  require('./routes/equipment'));
app.use('/api/rentals',    require('./routes/rentals'));
app.use('/api/admin',      require('./routes/admin'));

// ── MongoDB 연결 ──────────────────────────────────
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ MongoDB 연결 완료'))
  .catch((err) => console.error('❌ MongoDB 연결 실패:', err));

// ── 연체 자동 처리 크론 (매일 오전 0시) ────────────
cron.schedule('0 0 * * *', async () => {
  console.log('[CRON] 연체 상태 업데이트 실행');
  const now = new Date();
  const overdueRentals = await Rental.find({ status: 'ACTIVE', dueDate: { $lt: now } });

  for (const rental of overdueRentals) {
    rental.status = 'OVERDUE';
    await rental.save();

    // 패널티 자동 부과 (연체 1일 = 1점)
    const overdueDays = Math.floor((now - rental.dueDate) / 86400000);
    if (overdueDays >= 1) {
      await Penalty.create({
        user: rental.user,
        rental: rental._id,
        score: overdueDays,
        reason: `${overdueDays}일 연체 자동 부과`,
      });
      await User.findByIdAndUpdate(rental.user, { $inc: { penaltyScore: overdueDays } });
    }
  }
  console.log(`[CRON] ${overdueRentals.length}건 연체 처리 완료`);
});

// ── D-3, D-1 알림 크론 (매일 오전 9시) ────────────
cron.schedule('0 9 * * *', async () => {
  const now = new Date();
  const d1 = new Date(now); d1.setDate(d1.getDate() + 1);
  const d3 = new Date(now); d3.setDate(d3.getDate() + 3);

  const upcoming = await Rental.find({
    status: 'ACTIVE',
    dueDate: { $gte: now, $lte: d3 },
  }).populate('user equipment');

  for (const r of upcoming) {
    const days = Math.ceil((r.dueDate - now) / 86400000);
    console.log(`[알림] ${r.user.name} - ${r.equipment.modelName} D-${days} 알림 발송`);
    // TODO: FCM push 또는 이메일 발송 로직 추가
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 서버 실행 중: http://localhost:${PORT}`));
