const mongoose = require('mongoose');

// ── User ─────────────────────────────────────────
const userSchema = new mongoose.Schema({
  studentId: { type: String, required: true, unique: true },
  name:      { type: String, required: true },
  email:     { type: String, required: true, unique: true },
  password:  { type: String, required: true },
  phone:     String,
  penaltyScore: { type: Number, default: 0 },
  isSuspended:  { type: Boolean, default: false },
}, { timestamps: true });

// ── Admin ─────────────────────────────────────────
const adminSchema = new mongoose.Schema({
  adminId:    { type: String, required: true, unique: true },
  name:       { type: String, required: true },
  email:      { type: String, required: true, unique: true },
  password:   { type: String, required: true },
  department: String,
  level:      { type: String, enum: ['SUPER', 'STAFF'], default: 'STAFF' },
}, { timestamps: true });

// ── Category ──────────────────────────────────────
const categorySchema = new mongoose.Schema({
  name:           { type: String, required: true, unique: true },
  maxRentalDays:  { type: Number, default: 7 },
  iconColor:      { type: String, default: '#028090' },
});

// ── Equipment ─────────────────────────────────────
const equipmentSchema = new mongoose.Schema({
  category:     { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
  managedBy:    { type: mongoose.Schema.Types.ObjectId, ref: 'Admin' },
  serialNumber: { type: String, required: true, unique: true },
  modelName:    { type: String, required: true },
  qrCodeUrl:    String,
  images:       [String],
  status: {
    type: String,
    enum: ['AVAILABLE', 'RENTED', 'REPAIRING', 'LOST'],
    default: 'AVAILABLE',
  },
  maxRentalDays: { type: Number, default: 7 },
}, { timestamps: true });

// ── Rental ────────────────────────────────────────
const rentalSchema = new mongoose.Schema({
  user:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  equipment:  { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment', required: true },
  rentalDate: { type: Date, default: Date.now },
  dueDate:    { type: Date, required: true },
  returnDate: Date,
  returnPhotoUrl: String,
  status: {
    type: String,
    enum: ['ACTIVE', 'RETURNED', 'OVERDUE'],
    default: 'ACTIVE',
  },
  purpose:       String,
  isForceReturn: { type: Boolean, default: false },
  forceReturnReason: String,
  forceReturnBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Admin' },
  note: String,
}, { timestamps: true });

// ── Penalty ───────────────────────────────────────
const penaltySchema = new mongoose.Schema({
  user:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  rental:  { type: mongoose.Schema.Types.ObjectId, ref: 'Rental' },
  score:   { type: Number, required: true },
  reason:  { type: String, required: true },
  issuedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Admin' },
}, { timestamps: true });

// ── EquipmentStatusHistory ────────────────────────
const statusHistorySchema = new mongoose.Schema({
  equipment: { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment', required: true },
  admin:     { type: mongoose.Schema.Types.ObjectId, ref: 'Admin', required: true },
  status:    { type: String, required: true },
  reason:    String,
  changedAt: { type: Date, default: Date.now },
});

module.exports = {
  User:      mongoose.model('User', userSchema),
  Admin:     mongoose.model('Admin', adminSchema),
  Category:  mongoose.model('Category', categorySchema),
  Equipment: mongoose.model('Equipment', equipmentSchema),
  Rental:    mongoose.model('Rental', rentalSchema),
  Penalty:   mongoose.model('Penalty', penaltySchema),
  StatusHistory: mongoose.model('StatusHistory', statusHistorySchema),
};
