import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export const equipmentAPI = {
  getAll: (params) => api.get('/equipment', { params }),
  getOne: (id) => api.get(`/equipment/${id}`),
  create: (data) => api.post('/equipment', data),
  update: (id, data) => api.put(`/equipment/${id}`, data),
  delete: (id) => api.delete(`/equipment/${id}`),
  getQR: (id) => api.get(`/equipment/${id}/qr`),
};

export const rentalAPI = {
  getAll: (params) => api.get('/rentals', { params }),
  getMyRentals: () => api.get('/rentals/my'),
  create: (data) => api.post('/rentals', data),
  returnItem: (id, data) => api.put(`/rentals/${id}/return`, data),
  extend: (id, data) => api.put(`/rentals/${id}/extend`, data),
  forceReturn: (id, data) => api.put(`/rentals/${id}/force-return`, data),
};

export const categoryAPI = {
  getAll: () => api.get('/categories'),
  create: (data) => api.post('/categories', data),
  update: (id, data) => api.put(`/categories/${id}`, data),
  delete: (id) => api.delete(`/categories/${id}`),
};

export const authAPI = {
  login: (data) => api.post('/auth/login', data),
  adminLogin: (data) => api.post('/auth/admin/login', data),
  me: () => api.get('/auth/me'),
};

export const reportAPI = {
  stats: () => api.get('/admin/stats'),
  overdueList: () => api.get('/admin/overdue'),
};

export default api;
