import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';

import Login from './pages/Login';
import EquipmentList from './pages/EquipmentList';
import EquipmentDetail from './pages/EquipmentDetail';
import QRScan from './pages/QRScan';
import MyRentals from './pages/MyRentals';
import Notifications from './pages/Notifications';
import AdminDashboard from './pages/admin/Dashboard';
import AdminEquipment from './pages/admin/Equipment';
import AdminRentals from './pages/admin/Rentals';
import AdminPenalty from './pages/admin/Penalty';
import BottomNav from './components/BottomNav';

function PrivateRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading">로딩 중...</div>;
  return user ? children : <Navigate to="/login" />;
}

function AdminRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading">로딩 중...</div>;
  return user?.role === 'admin' ? children : <Navigate to="/" />;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <>
      <Routes>
        <Route path="/login" element={<Login />} />

        {/* 일반 사용자 */}
        <Route path="/" element={<PrivateRoute><EquipmentList /></PrivateRoute>} />
        <Route path="/equipment/:id" element={<PrivateRoute><EquipmentDetail /></PrivateRoute>} />
        <Route path="/scan" element={<PrivateRoute><QRScan /></PrivateRoute>} />
        <Route path="/my-rentals" element={<PrivateRoute><MyRentals /></PrivateRoute>} />
        <Route path="/notifications" element={<PrivateRoute><Notifications /></PrivateRoute>} />

        {/* 관리자 */}
        <Route path="/admin" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
        <Route path="/admin/equipment" element={<AdminRoute><AdminEquipment /></AdminRoute>} />
        <Route path="/admin/rentals" element={<AdminRoute><AdminRentals /></AdminRoute>} />
        <Route path="/admin/penalty" element={<AdminRoute><AdminPenalty /></AdminRoute>} />
      </Routes>
      {user && user.role !== 'admin' && <BottomNav />}
    </>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
