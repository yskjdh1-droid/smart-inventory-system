import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { equipmentAPI, categoryAPI } from '../api';
import { useAuth } from '../hooks/useAuth';

const STATUS_MAP = {
  AVAILABLE:  { label: '대여 가능', color: '#1D9E75', bg: '#E1F5EE' },
  RENTED:     { label: '대여 중',   color: '#A32D2D', bg: '#FCEBEB' },
  REPAIRING:  { label: '수리 중',   color: '#854F0B', bg: '#FAEEDA' },
  LOST:       { label: '분실',      color: '#5F5E5A', bg: '#F1EFE8' },
};

export default function EquipmentList() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [activeCat, setActiveCat] = useState('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    categoryAPI.getAll().then((res) => setCategories(res.data));
  }, []);

  useEffect(() => {
    setLoading(true);
    equipmentAPI
      .getAll({ category: activeCat === 'all' ? '' : activeCat, search })
      .then((res) => setItems(res.data))
      .finally(() => setLoading(false));
  }, [activeCat, search]);

  return (
    <div style={styles.page}>
      {/* 헤더 */}
      <div style={styles.header}>
        <div>
          <h1 style={styles.headerTitle}>기자재 목록</h1>
          <p style={styles.headerSub}>안녕하세요, {user?.name}님</p>
        </div>
        {user?.role === 'admin' && (
          <button style={styles.adminBtn} onClick={() => navigate('/admin')}>
            관리자
          </button>
        )}
      </div>

      {/* 검색 */}
      <div style={styles.searchWrap}>
        <input
          style={styles.searchInput}
          placeholder="기자재명 또는 코드 검색..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* 카테고리 칩 */}
      <div style={styles.chipRow}>
        <button
          style={activeCat === 'all' ? { ...styles.chip, ...styles.chipOn } : styles.chip}
          onClick={() => setActiveCat('all')}
        >
          전체
        </button>
        {categories.map((cat) => (
          <button
            key={cat._id}
            style={activeCat === cat._id ? { ...styles.chip, ...styles.chipOn } : styles.chip}
            onClick={() => setActiveCat(cat._id)}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* 목록 */}
      <div style={styles.list}>
        {loading ? (
          <p style={{ textAlign: 'center', color: '#888', paddingTop: 40 }}>불러오는 중...</p>
        ) : items.length === 0 ? (
          <p style={{ textAlign: 'center', color: '#888', paddingTop: 40 }}>검색 결과가 없습니다.</p>
        ) : (
          items.map((item) => {
            const s = STATUS_MAP[item.status] || STATUS_MAP.AVAILABLE;
            return (
              <div key={item._id} style={styles.card} onClick={() => navigate(`/equipment/${item._id}`)}>
                <div style={styles.thumb}>
                  <span style={{ fontSize: 24 }}>💻</span>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={styles.cardTitle}>{item.modelName}</div>
                  <div style={styles.cardSub}>{item.serialNumber} · {item.category?.name}</div>
                  <span style={{ ...styles.badge, color: s.color, background: s.bg }}>
                    {s.label}
                  </span>
                </div>
                <span style={styles.arrow}>›</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

const styles = {
  page: { paddingBottom: 72, minHeight: '100vh', background: '#F4F6F8' },
  header: { background: '#028090', padding: '20px 16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  headerTitle: { color: '#fff', fontSize: 20, fontWeight: 600, margin: 0 },
  headerSub: { color: 'rgba(255,255,255,.8)', fontSize: 13, marginTop: 2 },
  adminBtn: { background: 'rgba(255,255,255,.2)', color: '#fff', border: 'none', borderRadius: 8, padding: '6px 12px', fontSize: 13, cursor: 'pointer' },
  searchWrap: { padding: '12px 16px 0' },
  searchInput: { width: '100%', padding: '10px 14px', borderRadius: 10, border: '0.5px solid #E0E4E8', fontSize: 14, background: '#fff', outline: 'none' },
  chipRow: { display: 'flex', gap: 8, padding: '10px 16px', overflowX: 'auto' },
  chip: { padding: '5px 14px', borderRadius: 20, fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', cursor: 'pointer', border: '0.5px solid #E0E4E8', background: '#fff', color: '#6b7b8a' },
  chipOn: { background: '#028090', color: '#fff', borderColor: '#028090' },
  list: { padding: '4px 16px' },
  card: { background: '#fff', borderRadius: 14, border: '0.5px solid #E0E4E8', padding: 14, marginBottom: 10, display: 'flex', gap: 12, alignItems: 'center', cursor: 'pointer' },
  thumb: { width: 52, height: 52, borderRadius: 10, background: '#E1F5EE', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  cardTitle: { fontSize: 14, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  cardSub: { fontSize: 12, color: '#6b7b8a', marginTop: 2 },
  badge: { display: 'inline-block', padding: '2px 8px', borderRadius: 10, fontSize: 11, fontWeight: 600, marginTop: 4 },
  arrow: { fontSize: 20, color: '#ccc' },
};
