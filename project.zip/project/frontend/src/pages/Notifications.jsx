import { useState, useEffect } from 'react';
import api from '../api';

export default function Notifications() {
  const [notifs, setNotifs] = useState([]);

  useEffect(() => {
    api.get('/notifications').then((r) => setNotifs(r.data)).catch(() => {});
  }, []);

  const mock = [
    { _id: '1', type: 'overdue',  title: 'NB-001 MacBook Air',  body: '반납 예정일이 1일 초과됐습니다.',      time: '오전 9:00', read: false },
    { _id: '2', type: 'dueToday', title: 'CAM-002 Canon EOS R', body: '오늘 반납 예정입니다.',                time: '오전 9:00', read: false },
    { _id: '3', type: 'dueSoon',  title: 'TB-002 Galaxy Tab',   body: '반납 예정일이 2일 남았습니다.',        time: '어제',      read: true  },
    { _id: '4', type: 'approved', title: '연장 승인',            body: 'NB-003 대여 연장이 승인됐습니다.',    time: '2일 전',    read: true  },
    { _id: '5', type: 'penalty',  title: '패널티 부과',          body: '연체 2일로 인해 2점이 부과됐습니다.', time: '3일 전',    read: true  },
  ];

  const items = notifs.length ? notifs : mock;
  const typeStyle = {
    overdue:  { dot: '#E24B4A', bg: '#FCEBEB' },
    dueToday: { dot: '#EF9F27', bg: '#FAEEDA' },
    dueSoon:  { dot: '#EF9F27', bg: '#FAEEDA' },
    approved: { dot: '#1D9E75', bg: '#E1F5EE' },
    penalty:  { dot: '#E24B4A', bg: '#FCEBEB' },
  };

  return (
    <div style={{ background: '#F4F6F8', minHeight: '100vh', paddingBottom: 72 }}>
      <div style={{ background: '#028090', padding: '20px 16px' }}>
        <h1 style={{ color: '#fff', fontSize: 20, fontWeight: 600 }}>알림</h1>
        <p style={{ color: 'rgba(255,255,255,.8)', fontSize: 13, marginTop: 2 }}>반납 예정 및 연체 알림</p>
      </div>
      <div style={{ padding: '14px 16px' }}>
        {items.map((n) => {
          const ts = typeStyle[n.type] || { dot: '#888', bg: '#F1EFE8' };
          return (
            <div key={n._id} style={{ background: n.read ? '#fff' : '#F0FAF9', borderRadius: 14, border: `0.5px solid ${n.read ? '#E0E4E8' : '#9FE1CB'}`, padding: '12px 14px', marginBottom: 8, display: 'flex', gap: 10 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: ts.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: ts.dot }} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#1a1a1a' }}>{n.title}</div>
                <div style={{ fontSize: 12, color: '#6b7b8a', marginTop: 2, lineHeight: 1.5 }}>{n.body}</div>
                <div style={{ fontSize: 11, color: '#aaa', marginTop: 4 }}>{n.time}</div>
              </div>
              {!n.read && <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#028090', flexShrink: 0, marginTop: 4 }} />}
            </div>
          );
        })}
      </div>
    </div>
  );
}
