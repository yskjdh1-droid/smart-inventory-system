import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { equipmentAPI, rentalAPI } from '../api';

const STATUS_MAP = {
  AVAILABLE: { label: '대여 가능', color: '#1D9E75', bg: '#E1F5EE' },
  RENTED:    { label: '대여 중',   color: '#A32D2D', bg: '#FCEBEB' },
  REPAIRING: { label: '수리 중',   color: '#854F0B', bg: '#FAEEDA' },
  LOST:      { label: '분실',      color: '#5F5E5A', bg: '#F1EFE8' },
};

export default function EquipmentDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [item, setItem] = useState(null);
  const [dueDate, setDueDate] = useState('');
  const [purpose, setPurpose] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    equipmentAPI.getOne(id).then((res) => setItem(res.data));
  }, [id]);

  const handleRent = async () => {
    if (!dueDate) return alert('반납 예정일을 선택해주세요.');
    setSubmitting(true);
    try {
      await rentalAPI.create({ equipmentId: id, dueDate, purpose });
      setSuccess(true);
    } catch (e) {
      alert(e.response?.data?.message || '대여 신청에 실패했습니다.');
    } finally {
      setSubmitting(false);
    }
  };

  const minDate = new Date();
  minDate.setDate(minDate.getDate() + 1);
  const maxDate = new Date();
  maxDate.setDate(maxDate.getDate() + (item?.maxRentalDays || 7));

  if (!item) return <div style={{ padding: 40, textAlign: 'center', color: '#888' }}>불러오는 중...</div>;
  const s = STATUS_MAP[item.status];

  return (
    <div style={{ background: '#F4F6F8', minHeight: '100vh', paddingBottom: 20 }}>
      {/* 헤더 */}
      <div style={{ background: '#fff', padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '0.5px solid #E0E4E8' }}>
        <button onClick={() => navigate(-1)} style={{ background: '#F4F6F8', border: 'none', borderRadius: '50%', width: 32, height: 32, fontSize: 18, cursor: 'pointer' }}>‹</button>
        <h2 style={{ fontSize: 17, fontWeight: 600, flex: 1 }}>기자재 상세</h2>
      </div>

      {/* 이미지 영역 */}
      <div style={{ background: '#E1F5EE', height: 160, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 60 }}>
        💻
      </div>

      {/* 정보 */}
      <div style={{ background: '#fff', margin: '12px 16px', borderRadius: 14, padding: '14px 16px', border: '0.5px solid #E0E4E8' }}>
        <div style={{ fontSize: 18, fontWeight: 600 }}>{item.modelName}</div>
        <div style={{ fontSize: 13, color: '#6b7b8a', marginTop: 3 }}>{item.serialNumber} · {item.category?.name}</div>
        <span style={{ display: 'inline-block', marginTop: 6, padding: '3px 10px', borderRadius: 10, fontSize: 12, fontWeight: 600, color: s.color, background: s.bg }}>
          {s.label}
        </span>
        <div style={{ marginTop: 14, borderTop: '0.5px solid #E0E4E8', paddingTop: 12 }}>
          {[
            ['최대 대여 기간', `${item.maxRentalDays || 7}일`],
            ['시리얼 번호', item.serialNumber],
            ['카테고리', item.category?.name],
            ['담당 관리자', item.managedBy?.name || '-'],
          ].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '0.5px solid #F0F0F0', fontSize: 14 }}>
              <span style={{ color: '#6b7b8a' }}>{k}</span>
              <span style={{ fontWeight: 500 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 대여 신청 */}
      {item.status === 'AVAILABLE' && !success && (
        <div style={{ background: '#fff', margin: '0 16px', borderRadius: 14, padding: '14px 16px', border: '0.5px solid #E0E4E8' }}>
          <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>대여 신청</div>
          <div style={{ marginBottom: 10 }}>
            <label style={{ fontSize: 13, color: '#6b7b8a', display: 'block', marginBottom: 4 }}>반납 예정일 *</label>
            <input
              type="date"
              value={dueDate}
              min={minDate.toISOString().split('T')[0]}
              max={maxDate.toISOString().split('T')[0]}
              onChange={(e) => setDueDate(e.target.value)}
              style={{ width: '100%', padding: '10px 12px', borderRadius: 10, border: '0.5px solid #E0E4E8', fontSize: 14 }}
            />
          </div>
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 13, color: '#6b7b8a', display: 'block', marginBottom: 4 }}>사용 목적 (선택)</label>
            <input
              type="text"
              placeholder="예: 졸업 작품 촬영"
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              style={{ width: '100%', padding: '10px 12px', borderRadius: 10, border: '0.5px solid #E0E4E8', fontSize: 14 }}
            />
          </div>
          <button
            onClick={handleRent}
            disabled={submitting}
            style={{ width: '100%', padding: 14, borderRadius: 12, border: 'none', background: '#028090', color: '#fff', fontSize: 15, fontWeight: 600, cursor: 'pointer' }}
          >
            {submitting ? '신청 중...' : '대여 신청하기'}
          </button>
        </div>
      )}

      {success && (
        <div style={{ margin: '0 16px', background: '#E1F5EE', borderRadius: 14, padding: 20, textAlign: 'center' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>✅</div>
          <div style={{ fontSize: 16, fontWeight: 600, color: '#085041' }}>대여 신청 완료!</div>
          <div style={{ fontSize: 13, color: '#0F6E56', marginTop: 4 }}>반납 예정일: {dueDate}</div>
          <button onClick={() => navigate('/')} style={{ marginTop: 14, padding: '10px 24px', borderRadius: 10, border: 'none', background: '#028090', color: '#fff', fontSize: 14, cursor: 'pointer' }}>
            목록으로
          </button>
        </div>
      )}
    </div>
  );
}
