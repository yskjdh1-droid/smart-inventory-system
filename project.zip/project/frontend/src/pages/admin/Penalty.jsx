import { useState, useEffect } from 'react';
import api from '../../api';

export default function AdminPenalty() {
  const [users, setUsers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({ score: 1, reason: '' });
  const [mode, setMode] = useState('add'); // add | reduce

  const load = () => api.get('/admin/users').then((r) => setUsers(r.data));
  useEffect(() => { load(); }, []);

  const handle = async () => {
    if (!selected || !form.reason) return alert('사용자 선택 및 사유를 입력하세요.');
    try {
      if (mode === 'add') {
        await api.post('/admin/penalty', { userId: selected._id, score: form.score, reason: form.reason });
        alert(`${form.score}점 부과됐습니다.`);
      } else {
        await api.put(`/admin/penalty/${selected._id}/reduce`, { score: form.score, reason: form.reason });
        alert(`${form.score}점 감면됐습니다.`);
      }
      setSelected(null); setForm({ score: 1, reason: '' }); load();
    } catch (e) { alert(e.response?.data?.message || '처리 실패'); }
  };

  return (
    <div style={{ background: '#F4F6F8', minHeight: '100vh' }}>
      <div style={{ background: '#fff', padding: '14px 16px', borderBottom: '0.5px solid #E0E4E8' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600 }}>패널티 관리</h2>
      </div>

      {/* 부과/감면 폼 */}
      <div style={{ margin: '14px 16px', background: '#fff', borderRadius: 14, border: '0.5px solid #E0E4E8', padding: 16 }}>
        <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
          {['add', 'reduce'].map((m) => (
            <button key={m} onClick={() => setMode(m)}
              style={{ flex: 1, padding: '8px 0', borderRadius: 8, border: 'none', background: mode === m ? (m === 'add' ? '#FCEBEB' : '#E1F5EE') : '#F4F6F8', color: mode === m ? (m === 'add' ? '#A32D2D' : '#085041') : '#6b7b8a', fontWeight: mode === m ? 600 : 400, fontSize: 13, cursor: 'pointer' }}>
              {m === 'add' ? '패널티 부과' : '패널티 감면'}
            </button>
          ))}
        </div>
        <div style={{ marginBottom: 10 }}>
          <label style={{ fontSize: 12, color: '#6b7b8a', display: 'block', marginBottom: 4 }}>학생 선택</label>
          <select value={selected?._id || ''} onChange={(e) => setSelected(users.find((u) => u._id === e.target.value) || null)}
            style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '0.5px solid #E0E4E8', fontSize: 14 }}>
            <option value="">선택하세요</option>
            {users.map((u) => <option key={u._id} value={u._id}>{u.name} ({u.studentId}) — {u.penaltyScore}점</option>)}
          </select>
        </div>
        <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
          <div style={{ flex: 1 }}>
            <label style={{ fontSize: 12, color: '#6b7b8a', display: 'block', marginBottom: 4 }}>점수</label>
            <input type="number" min="1" max="20" value={form.score} onChange={(e) => setForm({ ...form, score: Number(e.target.value) })}
              style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '0.5px solid #E0E4E8', fontSize: 14 }} />
          </div>
          <div style={{ flex: 2 }}>
            <label style={{ fontSize: 12, color: '#6b7b8a', display: 'block', marginBottom: 4 }}>사유</label>
            <input value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })}
              placeholder="사유 입력"
              style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '0.5px solid #E0E4E8', fontSize: 14 }} />
          </div>
        </div>
        <button onClick={handle}
          style={{ width: '100%', padding: 11, borderRadius: 10, border: 'none', background: mode === 'add' ? '#A32D2D' : '#1D9E75', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
          {mode === 'add' ? '패널티 부과' : '패널티 감면'}
        </button>
      </div>

      {/* 학생 목록 */}
      <div style={{ padding: '0 16px' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#6b7b8a', marginBottom: 8 }}>전체 학생 패널티 현황</div>
        {users.map((u) => (
          <div key={u._id} style={{ background: '#fff', borderRadius: 14, border: `0.5px solid ${u.isSuspended ? '#F09595' : '#E0E4E8'}`, padding: '12px 14px', marginBottom: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600 }}>{u.name}</div>
              <div style={{ fontSize: 12, color: '#6b7b8a', marginTop: 2 }}>{u.studentId}</div>
              {u.isSuspended && <span style={{ fontSize: 11, color: '#A32D2D', fontWeight: 600, marginTop: 3, display: 'block' }}>대여 정지 중</span>}
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: u.penaltyScore >= 10 ? '#A32D2D' : u.penaltyScore >= 5 ? '#854F0B' : '#1D9E75' }}>
                {u.penaltyScore}점
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
