// ── AdminRentals.jsx ──────────────────────────────
import { useState, useEffect } from 'react';
import { rentalAPI } from '../../api';

const S = {
  ACTIVE:   { label: '대여 중',   color: '#1D9E75', bg: '#E1F5EE' },
  RETURNED: { label: '반납 완료', color: '#5F5E5A', bg: '#F1EFE8' },
  OVERDUE:  { label: '연체',     color: '#A32D2D', bg: '#FCEBEB' },
};

export function AdminRentals() {
  const [rentals, setRentals] = useState([]);
  const [filter, setFilter] = useState('ACTIVE');

  const load = () => rentalAPI.getAll({ status: filter }).then((r) => setRentals(r.data));
  useEffect(() => { load(); }, [filter]);

  const handleForce = async (id) => {
    const reason = prompt('강제 반납 사유:');
    if (!reason) return;
    await rentalAPI.forceReturn(id, { reason });
    load();
  };

  return (
    <div style={{ background: '#F4F6F8', minHeight: '100vh' }}>
      <div style={{ background: '#fff', padding: '14px 16px', borderBottom: '0.5px solid #E0E4E8' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600 }}>대여 현황</h2>
      </div>
      <div style={{ display: 'flex', background: '#fff', borderBottom: '0.5px solid #E0E4E8' }}>
        {['ACTIVE', 'OVERDUE', 'RETURNED'].map((s) => (
          <button key={s} onClick={() => setFilter(s)}
            style={{ flex: 1, padding: '11px 0', border: 'none', background: 'transparent', fontSize: 13, fontWeight: filter === s ? 600 : 400, color: filter === s ? '#028090' : '#6b7b8a', borderBottom: filter === s ? '2px solid #028090' : '2px solid transparent', cursor: 'pointer' }}>
            {S[s].label}
          </button>
        ))}
      </div>
      <div style={{ padding: '12px 16px' }}>
        {rentals.map((r) => {
          const st = S[r.status];
          return (
            <div key={r._id} style={{ background: '#fff', borderRadius: 14, border: '0.5px solid #E0E4E8', padding: '12px 14px', marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{r.equipment?.modelName}</div>
                  <div style={{ fontSize: 12, color: '#6b7b8a', marginTop: 2 }}>{r.user?.name} · {r.user?.studentId}</div>
                </div>
                <span style={{ padding: '3px 8px', borderRadius: 10, fontSize: 11, fontWeight: 600, color: st.color, background: st.bg }}>{st.label}</span>
              </div>
              <div style={{ marginTop: 8, fontSize: 12, color: '#6b7b8a', display: 'flex', gap: 12 }}>
                <span>대여일: {new Date(r.rentalDate).toLocaleDateString('ko-KR')}</span>
                <span>반납 예정: {new Date(r.dueDate).toLocaleDateString('ko-KR')}</span>
              </div>
              {r.status !== 'RETURNED' && (
                <button onClick={() => handleForce(r._id)}
                  style={{ marginTop: 8, padding: '6px 14px', borderRadius: 8, border: 'none', background: '#FCEBEB', color: '#A32D2D', fontSize: 12, fontWeight: 500, cursor: 'pointer' }}>
                  강제 반납
                </button>
              )}
            </div>
          );
        })}
        {!rentals.length && <p style={{ textAlign: 'center', color: '#888', paddingTop: 40 }}>내역이 없습니다.</p>}
      </div>
    </div>
  );
}

export default AdminRentals;
