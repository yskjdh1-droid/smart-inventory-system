import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { reportAPI, rentalAPI } from '../../api';
import { useAuth } from '../../hooks/useAuth';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [stats, setStats] = useState(null);
  const [overdue, setOverdue] = useState([]);

  useEffect(() => {
    reportAPI.stats().then((res) => setStats(res.data));
    reportAPI.overdueList().then((res) => setOverdue(res.data));
  }, []);

  const handleForceReturn = async (rentalId) => {
    const reason = prompt('강제 반납 사유를 입력하세요:');
    if (!reason) return;
    try {
      await rentalAPI.forceReturn(rentalId, { reason });
      alert('강제 반납 처리됐습니다.');
      reportAPI.overdueList().then((res) => setOverdue(res.data));
    } catch {
      alert('처리 중 오류가 발생했습니다.');
    }
  };

  return (
    <div style={{ background: '#F4F6F8', minHeight: '100vh' }}>
      {/* 헤더 */}
      <div style={{ background: '#0D2B2B', padding: '20px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ color: '#fff', fontSize: 20, fontWeight: 600 }}>관리자 대시보드</h1>
          <p style={{ color: 'rgba(255,255,255,.6)', fontSize: 12, marginTop: 2 }}>기자재 대여 관리 시스템</p>
        </div>
        <button onClick={logout} style={{ background: 'rgba(255,255,255,.1)', border: 'none', color: '#fff', padding: '6px 12px', borderRadius: 8, fontSize: 13, cursor: 'pointer' }}>로그아웃</button>
      </div>

      {/* 메뉴 */}
      <div style={{ display: 'flex', gap: 0, background: '#fff', borderBottom: '0.5px solid #E0E4E8', overflowX: 'auto' }}>
        {[['/', '대시보드'], ['/admin/equipment', '기자재 관리'], ['/admin/rentals', '대여 현황'], ['/admin/penalty', '패널티']].map(([path, label]) => (
          <button key={path} onClick={() => navigate(path)}
            style={{ padding: '12px 16px', border: 'none', background: 'transparent', fontSize: 13, fontWeight: path === '/admin' ? 600 : 400, color: path === '/admin' ? '#028090' : '#6b7b8a', borderBottom: path === '/admin' ? '2px solid #028090' : '2px solid transparent', whiteSpace: 'nowrap', cursor: 'pointer' }}>
            {label}
          </button>
        ))}
      </div>

      <div style={{ padding: '14px 16px' }}>
        {/* 통계 카드 */}
        {stats && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
            {[
              { label: '전체 기자재', value: stats.total, color: '#1a1a1a' },
              { label: '대여 가능', value: stats.available, color: '#1D9E75' },
              { label: '대여 중', value: stats.rented, color: '#854F0B' },
              { label: '연체', value: stats.overdue, color: '#A32D2D' },
            ].map(({ label, value, color }) => (
              <div key={label} style={{ background: '#fff', borderRadius: 12, padding: '14px 16px', border: '0.5px solid #E0E4E8' }}>
                <div style={{ fontSize: 12, color: '#6b7b8a' }}>{label}</div>
                <div style={{ fontSize: 26, fontWeight: 600, color, marginTop: 2 }}>{value}</div>
              </div>
            ))}
          </div>
        )}

        {/* 연체 목록 */}
        <div style={{ background: '#fff', borderRadius: 14, border: '0.5px solid #E0E4E8', overflow: 'hidden', marginBottom: 16 }}>
          <div style={{ padding: '12px 16px', borderBottom: '0.5px solid #E0E4E8', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 600, fontSize: 14 }}>연체 목록</span>
            <span style={{ background: '#FCEBEB', color: '#A32D2D', padding: '2px 8px', borderRadius: 10, fontSize: 12, fontWeight: 600 }}>{overdue.length}건</span>
          </div>
          {overdue.length === 0 ? (
            <p style={{ padding: 20, textAlign: 'center', color: '#888', fontSize: 13 }}>연체 없음</p>
          ) : (
            overdue.map((r) => (
              <div key={r._id} style={{ padding: '12px 16px', borderBottom: '0.5px solid #F4F6F8', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{r.equipment?.modelName}</div>
                  <div style={{ fontSize: 12, color: '#6b7b8a' }}>{r.user?.name} · {r.user?.studentId}</div>
                  <div style={{ fontSize: 11, color: '#A32D2D', marginTop: 2 }}>
                    {Math.floor((Date.now() - new Date(r.dueDate)) / 86400000)}일 연체
                  </div>
                </div>
                <button
                  onClick={() => handleForceReturn(r._id)}
                  style={{ padding: '6px 12px', borderRadius: 8, border: 'none', background: '#FCEBEB', color: '#A32D2D', fontSize: 12, fontWeight: 500, cursor: 'pointer' }}>
                  강제 반납
                </button>
              </div>
            ))
          )}
        </div>

        {/* 바로가기 */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {[
            { label: '기자재 등록', path: '/admin/equipment', color: '#028090', bg: '#E1F5EE' },
            { label: '연장 요청 처리', path: '/admin/rentals', color: '#5E60CE', bg: '#EEEDFE' },
            { label: '패널티 관리', path: '/admin/penalty', color: '#854F0B', bg: '#FAEEDA' },
            { label: '전체 대여 이력', path: '/admin/rentals', color: '#5F5E5A', bg: '#F1EFE8' },
          ].map(({ label, path, color, bg }) => (
            <button key={label} onClick={() => navigate(path)}
              style={{ padding: 16, borderRadius: 12, border: 'none', background: bg, color, fontSize: 14, fontWeight: 600, cursor: 'pointer', textAlign: 'left' }}>
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
