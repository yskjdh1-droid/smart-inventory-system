import { useState, useEffect } from 'react';
import { equipmentAPI, categoryAPI } from '../../api';

const STATUS_MAP = {
  AVAILABLE:  { label: '대여 가능', color: '#1D9E75', bg: '#E1F5EE' },
  RENTED:     { label: '대여 중',   color: '#A32D2D', bg: '#FCEBEB' },
  REPAIRING:  { label: '수리 중',   color: '#854F0B', bg: '#FAEEDA' },
  LOST:       { label: '분실',      color: '#5F5E5A', bg: '#F1EFE8' },
};

export default function AdminEquipment() {
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ modelName: '', serialNumber: '', category: '', maxRentalDays: 7 });
  const [submitting, setSubmitting] = useState(false);

  const load = () => {
    equipmentAPI.getAll().then((r) => setItems(r.data));
    categoryAPI.getAll().then((r) => setCategories(r.data));
  };

  useEffect(() => { load(); }, []);

  const handleAdd = async () => {
    if (!form.modelName || !form.serialNumber || !form.category) return alert('필수 항목을 입력해주세요.');
    setSubmitting(true);
    try {
      await equipmentAPI.create(form);
      setShowForm(false);
      setForm({ modelName: '', serialNumber: '', category: '', maxRentalDays: 7 });
      load();
    } catch (e) {
      alert(e.response?.data?.message || '등록 실패');
    } finally { setSubmitting(false); }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`"${name}"을(를) 삭제하시겠습니까?`)) return;
    await equipmentAPI.delete(id);
    load();
  };

  return (
    <div style={{ background: '#F4F6F8', minHeight: '100vh' }}>
      <div style={{ background: '#fff', padding: '14px 16px', borderBottom: '0.5px solid #E0E4E8', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600 }}>기자재 관리</h2>
        <button onClick={() => setShowForm(!showForm)}
          style={{ padding: '7px 14px', borderRadius: 8, border: 'none', background: '#028090', color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
          + 등록
        </button>
      </div>

      {showForm && (
        <div style={{ margin: '14px 16px', background: '#fff', borderRadius: 14, border: '0.5px solid #E0E4E8', padding: 16 }}>
          <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 14 }}>기자재 등록</div>
          {[
            { label: '모델명 *', key: 'modelName', placeholder: 'MacBook Air 13 (M2)' },
            { label: '시리얼 번호 *', key: 'serialNumber', placeholder: 'NB-001' },
          ].map(({ label, key, placeholder }) => (
            <div key={key} style={{ marginBottom: 10 }}>
              <label style={{ fontSize: 12, color: '#6b7b8a', display: 'block', marginBottom: 4 }}>{label}</label>
              <input value={form[key]} onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                placeholder={placeholder}
                style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '0.5px solid #E0E4E8', fontSize: 14 }} />
            </div>
          ))}
          <div style={{ marginBottom: 10 }}>
            <label style={{ fontSize: 12, color: '#6b7b8a', display: 'block', marginBottom: 4 }}>카테고리 *</label>
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
              style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '0.5px solid #E0E4E8', fontSize: 14 }}>
              <option value="">선택</option>
              {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
            </select>
          </div>
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: '#6b7b8a', display: 'block', marginBottom: 4 }}>최대 대여 기간 (일)</label>
            <input type="number" min="1" max="30" value={form.maxRentalDays}
              onChange={(e) => setForm({ ...form, maxRentalDays: Number(e.target.value) })}
              style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '0.5px solid #E0E4E8', fontSize: 14 }} />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={handleAdd} disabled={submitting}
              style={{ flex: 1, padding: 11, borderRadius: 10, border: 'none', background: '#028090', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
              {submitting ? '등록 중...' : '등록하기'}
            </button>
            <button onClick={() => setShowForm(false)}
              style={{ flex: 1, padding: 11, borderRadius: 10, border: '0.5px solid #E0E4E8', background: '#fff', color: '#6b7b8a', fontSize: 14, cursor: 'pointer' }}>
              취소
            </button>
          </div>
        </div>
      )}

      <div style={{ padding: '8px 16px' }}>
        {items.map((item) => {
          const s = STATUS_MAP[item.status] || STATUS_MAP.AVAILABLE;
          return (
            <div key={item._id} style={{ background: '#fff', borderRadius: 14, border: '0.5px solid #E0E4E8', padding: '12px 14px', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{item.modelName}</div>
                <div style={{ fontSize: 12, color: '#6b7b8a', marginTop: 2 }}>{item.serialNumber} · {item.category?.name}</div>
                <span style={{ padding: '2px 8px', borderRadius: 10, fontSize: 11, fontWeight: 600, color: s.color, background: s.bg, marginTop: 4, display: 'inline-block' }}>{s.label}</span>
              </div>
              <button onClick={() => handleDelete(item._id, item.modelName)}
                style={{ padding: '6px 12px', borderRadius: 8, border: 'none', background: '#FCEBEB', color: '#A32D2D', fontSize: 12, cursor: 'pointer' }}>삭제</button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
