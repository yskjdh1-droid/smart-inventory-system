import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { equipmentAPI, rentalAPI } from '../api';

export default function QRScan() {
  const navigate = useNavigate();
  const [mode, setMode] = useState('scan'); // scan | result | return
  const [scanned, setScanned] = useState(null);
  const [manualCode, setManualCode] = useState('');
  const [photo, setPhoto] = useState(null);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef();

  const handleScan = async (serialNumber) => {
    setLoading(true);
    try {
      const res = await equipmentAPI.getAll({ search: serialNumber });
      if (res.data.length === 0) return alert('기자재를 찾을 수 없습니다.');
      const item = res.data[0];
      setScanned(item);
      setMode(item.status === 'RENTED' ? 'return' : 'result');
    } catch {
      alert('조회 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const handleReturn = async () => {
    if (!photo) return alert('반납 전 상태 사진을 촬영해주세요.');
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('photo', photo);
      formData.append('equipmentId', scanned._id);
      await rentalAPI.returnItem(scanned.activeRentalId, formData);
      alert('반납이 완료됐습니다!');
      navigate('/');
    } catch (e) {
      alert(e.response?.data?.message || '반납 처리 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ background: '#F4F6F8', minHeight: '100vh', paddingBottom: 72 }}>
      <div style={{ background: '#028090', padding: '20px 16px' }}>
        <h1 style={{ color: '#fff', fontSize: 20, fontWeight: 600 }}>QR 스캔</h1>
        <p style={{ color: 'rgba(255,255,255,.8)', fontSize: 13, marginTop: 2 }}>
          기자재에 부착된 QR 코드를 스캔하세요
        </p>
      </div>

      <div style={{ padding: 16 }}>
        {mode === 'scan' && (
          <>
            {/* 카메라 뷰파인더 */}
            <div style={{ background: '#0D2B2B', borderRadius: 16, padding: 20, textAlign: 'center', marginBottom: 16 }}>
              <div style={{ width: 200, height: 200, margin: '0 auto', position: 'relative', border: '2px solid #02C39A', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ color: '#02C39A', fontSize: 13 }}>카메라 영역</div>
                <div style={{ position: 'absolute', top: -2, left: -2, width: 20, height: 20, borderTop: '3px solid #02C39A', borderLeft: '3px solid #02C39A', borderRadius: '4px 0 0 0' }} />
                <div style={{ position: 'absolute', top: -2, right: -2, width: 20, height: 20, borderTop: '3px solid #02C39A', borderRight: '3px solid #02C39A', borderRadius: '0 4px 0 0' }} />
                <div style={{ position: 'absolute', bottom: -2, left: -2, width: 20, height: 20, borderBottom: '3px solid #02C39A', borderLeft: '3px solid #02C39A', borderRadius: '0 0 0 4px' }} />
                <div style={{ position: 'absolute', bottom: -2, right: -2, width: 20, height: 20, borderBottom: '3px solid #02C39A', borderRight: '3px solid #02C39A', borderRadius: '0 0 4px 0' }} />
              </div>
              <p style={{ color: 'rgba(255,255,255,.6)', fontSize: 12, marginTop: 14 }}>
                QR 코드를 화면 중앙에 맞춰주세요
              </p>
            </div>

            {/* 수동 입력 */}
            <div style={{ background: '#fff', borderRadius: 14, padding: 14, border: '0.5px solid #E0E4E8', marginBottom: 12 }}>
              <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 8 }}>코드 직접 입력</div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  ref={inputRef}
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder="NB-001"
                  style={{ flex: 1, padding: '9px 12px', borderRadius: 8, border: '0.5px solid #E0E4E8', fontSize: 14 }}
                />
                <button
                  onClick={() => handleScan(manualCode)}
                  disabled={!manualCode || loading}
                  style={{ padding: '9px 16px', borderRadius: 8, border: 'none', background: '#028090', color: '#fff', fontSize: 14, cursor: 'pointer' }}
                >
                  조회
                </button>
              </div>
            </div>
          </>
        )}

        {/* 대여 결과 */}
        {mode === 'result' && scanned && (
          <div style={{ background: '#fff', borderRadius: 16, padding: 16, border: '0.5px solid #E0E4E8' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ width: 48, height: 48, borderRadius: 10, background: '#E1F5EE', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>💻</div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 15 }}>{scanned.modelName}</div>
                <div style={{ fontSize: 12, color: '#6b7b8a' }}>{scanned.serialNumber}</div>
              </div>
            </div>
            <div style={{ background: '#E1F5EE', borderRadius: 10, padding: 12, marginBottom: 16, textAlign: 'center', color: '#085041', fontWeight: 500 }}>
              대여 가능한 기자재입니다
            </div>
            <button
              onClick={() => navigate(`/equipment/${scanned._id}`)}
              style={{ width: '100%', padding: 13, borderRadius: 12, border: 'none', background: '#028090', color: '#fff', fontSize: 15, fontWeight: 600, cursor: 'pointer' }}
            >
              대여 신청하기
            </button>
            <button onClick={() => setMode('scan')} style={{ width: '100%', padding: 13, borderRadius: 12, border: '0.5px solid #E0E4E8', background: '#fff', color: '#028090', fontSize: 14, cursor: 'pointer', marginTop: 8 }}>
              다시 스캔
            </button>
          </div>
        )}

        {/* 반납 처리 */}
        {mode === 'return' && scanned && (
          <div style={{ background: '#fff', borderRadius: 16, padding: 16, border: '0.5px solid #E0E4E8' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ width: 48, height: 48, borderRadius: 10, background: '#FCEBEB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>💻</div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 15 }}>{scanned.modelName}</div>
                <div style={{ fontSize: 12, color: '#A32D2D', marginTop: 2 }}>현재 대여 중</div>
              </div>
            </div>
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 8 }}>반납 전 상태 촬영 *</div>
              <label style={{ display: 'block', background: photo ? '#E1F5EE' : '#F4F6F8', border: '1.5px dashed #E0E4E8', borderRadius: 12, padding: 20, textAlign: 'center', cursor: 'pointer' }}>
                <input type="file" accept="image/*" capture="environment" onChange={(e) => setPhoto(e.target.files[0])} style={{ display: 'none' }} />
                {photo ? <div style={{ color: '#1D9E75', fontWeight: 500 }}>📷 {photo.name}</div> : <div style={{ color: '#6b7b8a', fontSize: 13 }}>📷 카메라로 촬영하기<br /><span style={{ fontSize: 11 }}>기자재 상태를 명확히 촬영해주세요</span></div>}
              </label>
            </div>
            <button
              onClick={handleReturn}
              disabled={loading}
              style={{ width: '100%', padding: 13, borderRadius: 12, border: 'none', background: '#E24B4A', color: '#fff', fontSize: 15, fontWeight: 600, cursor: 'pointer' }}
            >
              {loading ? '처리 중...' : '반납 처리하기'}
            </button>
            <button onClick={() => setMode('scan')} style={{ width: '100%', padding: 12, borderRadius: 12, border: 'none', background: '#fff', color: '#6b7b8a', fontSize: 13, cursor: 'pointer', marginTop: 6 }}>
              취소
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
