import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export default function Login() {
  const navigate = useNavigate();
  const { login, adminLogin } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [form, setForm] = useState({ id: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    if (!form.id || !form.password) return setError('아이디와 비밀번호를 입력해주세요.');
    setLoading(true);
    setError('');
    try {
      if (isAdmin) {
        await adminLogin(form.id, form.password);
        navigate('/admin');
      } else {
        await login(form.id, form.password);
        navigate('/');
      }
    } catch (e) {
      setError(e.response?.data?.message || '로그인에 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#F4F6F8', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      {/* 로고 */}
      <div style={{ textAlign: 'center', marginBottom: 32 }}>
        <div style={{ width: 64, height: 64, borderRadius: 18, background: '#028090', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px', fontSize: 28 }}>📦</div>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: '#0D2B2B' }}>기자재 대여 관리</h1>
        <p style={{ fontSize: 13, color: '#6b7b8a', marginTop: 4 }}>스마트 학과 기자재 대여 시스템</p>
      </div>

      {/* 로그인 카드 */}
      <div style={{ width: '100%', maxWidth: 360, background: '#fff', borderRadius: 20, border: '0.5px solid #E0E4E8', padding: 24 }}>
        {/* 탭 */}
        <div style={{ display: 'flex', background: '#F4F6F8', borderRadius: 10, padding: 3, marginBottom: 20 }}>
          {[false, true].map((admin) => (
            <button key={String(admin)} onClick={() => { setIsAdmin(admin); setError(''); setForm({ id: '', password: '' }); }}
              style={{ flex: 1, padding: '8px 0', borderRadius: 8, border: 'none', fontSize: 14, fontWeight: 500, cursor: 'pointer', background: isAdmin === admin ? '#fff' : 'transparent', color: isAdmin === admin ? '#028090' : '#6b7b8a', transition: 'all .15s' }}>
              {admin ? '관리자' : '학생'}
            </button>
          ))}
        </div>

        {/* 폼 */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 13, color: '#6b7b8a', display: 'block', marginBottom: 5 }}>
            {isAdmin ? '관리자 ID' : '학번'}
          </label>
          <input
            value={form.id}
            onChange={(e) => setForm({ ...form, id: e.target.value })}
            placeholder={isAdmin ? '관리자 ID 입력' : '20XXXXXXXX'}
            style={{ width: '100%', padding: '11px 14px', borderRadius: 10, border: '0.5px solid #E0E4E8', fontSize: 15, outline: 'none' }}
          />
        </div>
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 13, color: '#6b7b8a', display: 'block', marginBottom: 5 }}>비밀번호</label>
          <input
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            placeholder="비밀번호 입력"
            style={{ width: '100%', padding: '11px 14px', borderRadius: 10, border: '0.5px solid #E0E4E8', fontSize: 15, outline: 'none' }}
          />
        </div>

        {error && (
          <div style={{ background: '#FCEBEB', borderRadius: 8, padding: '9px 12px', marginBottom: 14, fontSize: 13, color: '#A32D2D' }}>
            {error}
          </div>
        )}

        <button onClick={handleSubmit} disabled={loading}
          style={{ width: '100%', padding: 14, borderRadius: 12, border: 'none', background: '#028090', color: '#fff', fontSize: 16, fontWeight: 600, cursor: 'pointer', opacity: loading ? .7 : 1 }}>
          {loading ? '로그인 중...' : '로그인'}
        </button>
      </div>
    </div>
  );
}
