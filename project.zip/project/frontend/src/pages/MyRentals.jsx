import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { rentalAPI } from '../api';

const STATUS_MAP = {
  ACTIVE:    { label: '대여 중',  color: '#1D9E75', bg: '#E1F5EE' },
  RETURNED:  { label: '반납 완료', color: '#5F5E5A', bg: '#F1EFE8' },
  OVERDUE:   { label: '연체',     color: '#A32D2D', bg: '#FCEBEB' },
};

export default function MyRentals() {
  const navigate = useNavigate();
  const [rentals, setRentals] = useState([]);
  const [tab, setTab] = useState('active');

  useEffect(() => {
    rentalAPI.getMyRentals().then((res) => setRentals(res.data));
  }, []);

  const filtered = rentals.filter((r) =>
    tab === 'active' ? ['ACTIVE', 'OVERDUE'].includes(r.status) : r.status === 'RETURNED'
  );

  return (
    <div style={{ background: '#F4F6F8', minHeight: '100vh', paddingBottom: 72 }}>
      <div style={{ background: '#028090', padding: '20px 16px' }}>
        <h1 style={{ color: '#fff', fontSize: 20, fontWeight: 600 }}>내 대여 현황</h1>
      </div>

      {/* 탭 */}
      <div style={{ display: 'flex', background: '#fff', borderBottom: '0.5px solid #E0E4E8' }}>
        {[['active', '대여 중'], ['history', '반납 이력']].map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)}
            style={{ flex: 1, padding: '12px 0', border: 'none', background: 'transparent', fontSize: 14, fontWeight: tab === key ? 600 : 400, color: tab === key ? '#028090' : '#6b7b8a', borderBottom: tab === key ? '2px solid #028090' : '2px solid transparent', cursor: 'pointer' }}>
            {label}
          </button>
        ))}
      </div>

      <div style={{ padding: '14px 16px' }}>
        {filtered.length === 0 ? (
          <p style={{ textAlign: 'center', color: '#888', paddingTop: 40 }}>내역이 없습니다.</p>
        ) : (
          filtered.map((r) => {
            const s = STATUS_MAP[r.status];
            const due = new Date(r.dueDate);
            const isOverdue = r.status === 'OVERDUE';
            return (
              <div key={r._id} style={{ background: '#fff', borderRadius: 14, border: `0.5px solid ${isOverdue ? '#F09595' : '#E0E4E8'}`, padding: 14, marginBottom: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{r.equipment?.modelName}</div>
                    <div style={{ fontSize: 12, color: '#6b7b8a', marginTop: 2 }}>{r.equipment?.serialNumber}</div>
                  </div>
                  <span style={{ padding: '3px 10px', borderRadius: 10, fontSize: 11, fontWeight: 600, color: s.color, background: s.bg }}>{s.label}</span>
                </div>
                <div style={{ marginTop: 10, display: 'flex', gap: 16, fontSize: 12, color: '#6b7b8a' }}>
                  <span>대여일: {new Date(r.rentalDate).toLocaleDateString('ko-KR')}</span>
                  <span style={{ color: isOverdue ? '#A32D2D' : 'inherit' }}>
                    반납 예정: {due.toLocaleDateString('ko-KR')}
                  </span>
                </div>
                {r.status === 'ACTIVE' && (
                  <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                    <button onClick={() => navigate('/scan')}
                      style={{ flex: 1, padding: '8px 0', borderRadius: 8, border: 'none', background: '#028090', color: '#fff', fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>
                      반납하기
                    </button>
                    <button style={{ flex: 1, padding: '8px 0', borderRadius: 8, border: '0.5px solid #E0E4E8', background: '#fff', color: '#028090', fontSize: 13, cursor: 'pointer' }}>
                      연장 신청
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
