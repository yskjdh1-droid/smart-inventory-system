import { useNavigate, useLocation } from 'react-router-dom';

const tabs = [
  { path: '/',             label: '홈',     icon: '🏠' },
  { path: '/scan',         label: 'QR 스캔', icon: '📷' },
  { path: '/my-rentals',  label: '내 대여', icon: '📋' },
  { path: '/notifications',label: '알림',   icon: '🔔' },
];

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div style={{
      position: 'fixed', bottom: 0, left: 0, right: 0,
      background: '#fff', borderTop: '0.5px solid #E0E4E8',
      display: 'flex', zIndex: 100, paddingBottom: 'env(safe-area-inset-bottom)',
    }}>
      {tabs.map(({ path, label, icon }) => {
        const active = location.pathname === path;
        return (
          <button key={path} onClick={() => navigate(path)}
            style={{ flex: 1, padding: '8px 4px 6px', border: 'none', background: 'transparent', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, cursor: 'pointer' }}>
            <span style={{ fontSize: 20 }}>{icon}</span>
            <span style={{ fontSize: 10, color: active ? '#028090' : '#6b7b8a', fontWeight: active ? 600 : 400 }}>{label}</span>
            {active && <div style={{ width: 4, height: 4, borderRadius: '50%', background: '#028090' }} />}
          </button>
        );
      })}
    </div>
  );
}
