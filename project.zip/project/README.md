# 스마트 학과 기자재 대여 관리 시스템

## 기술 스택
| 구분 | 기술 |
|------|------|
| 프론트엔드 | React 18 + React Router v6 |
| 백엔드 | Node.js + Express |
| 데이터베이스 | MongoDB + Mongoose |
| 인증 | JWT |

---

## 프로젝트 구조

```
project/
├── frontend/
│   ├── src/
│   │   ├── api/          # axios 인스턴스 + API 함수
│   │   ├── hooks/        # useAuth (AuthContext)
│   │   ├── components/   # BottomNav 등 공통 컴포넌트
│   │   └── pages/
│   │       ├── Login.jsx
│   │       ├── EquipmentList.jsx
│   │       ├── EquipmentDetail.jsx
│   │       ├── QRScan.jsx
│   │       ├── MyRentals.jsx
│   │       ├── Notifications.jsx
│   │       └── admin/
│   │           ├── Dashboard.jsx
│   │           ├── Equipment.jsx
│   │           ├── Rentals.jsx
│   │           └── Penalty.jsx
│   └── package.json
│
└── backend/
    ├── models/       # User, Admin, Equipment, Rental, Penalty ...
    ├── routes/       # auth, categories, equipment, rentals, admin
    ├── middleware/   # JWT 인증, 관리자 권한 체크
    ├── server.js     # Express + MongoDB + Cron
    ├── .env.example
    └── package.json
```

---

## 실행 방법

### 1. 백엔드

```bash
cd backend
npm install
cp .env.example .env   # MONGODB_URI, JWT_SECRET 설정
npm run dev            # nodemon server.js → localhost:5000
```

### 2. 프론트엔드

```bash
cd frontend
npm install
npm start              # localhost:3000 (proxy → 5000)
```

---

## 주요 API 엔드포인트

| Method | URL | 설명 |
|--------|-----|------|
| POST | /api/auth/login | 학생 로그인 |
| POST | /api/auth/admin/login | 관리자 로그인 |
| GET  | /api/equipment | 기자재 목록 (검색/필터) |
| POST | /api/equipment | 기자재 등록 (관리자) |
| GET  | /api/equipment/:id/qr | QR 코드 조회 |
| GET  | /api/rentals/my | 내 대여 목록 |
| POST | /api/rentals | 대여 신청 |
| PUT  | /api/rentals/:id/return | 반납 처리 |
| PUT  | /api/rentals/:id/extend | 연장 신청 |
| PUT  | /api/rentals/:id/force-return | 강제 반납 (관리자) |
| GET  | /api/admin/stats | 대시보드 통계 |
| GET  | /api/admin/overdue | 연체 목록 |
| POST | /api/admin/penalty | 패널티 부과 |

---

## 자동화 기능 (node-cron)
- **매일 오전 0시**: 연체 상태 자동 전환 + 패널티 자동 부과
- **매일 오전 9시**: D-3, D-1 반납 예정 알림 발송
